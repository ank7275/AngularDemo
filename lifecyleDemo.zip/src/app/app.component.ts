import { Component ,OnInit} from '@angular/core';
import { FormGroup,FormControl,Validators } from '@angular/forms';
import { Data } from './data';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'lifecyleDemo';
  fg:FormGroup;
  fc:FormControl;
  data:Data;
  datas:Array<Data>=[];
  constructor(){

  }

  ngOnInit(){
    this.fg=new FormGroup({
      state:new FormControl('', [
      Validators.required,
      Validators.minLength(2)]),
      country:new FormControl(),
      date:new FormControl()
    });
  }

  onSubmit(){
    this.data=new Data();
    this.data.state=this.fg.get('state').value;
    this.data.country=this.fg.get('country').value;
    this.data.date=this.fg.get('date').value;
    this.datas.push(this.data);
    console.log(this.datas);
  }
}
