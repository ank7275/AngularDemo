export class Data{
   state:string;
   country:string;
   date:string;

}
