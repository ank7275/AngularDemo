import { Car } from './Cars';

export const CARS:Car[] = [
  {name:'Maruti',model:23114,color:'blue'},
  {name:'wagon R',model:23684,color:'blue'}
];
