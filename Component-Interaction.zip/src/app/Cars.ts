export class Car{
  name:string;
  model:number;
  color:string;
}
