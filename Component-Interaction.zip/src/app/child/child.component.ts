import { Component, OnInit ,Input} from '@angular/core';
import { Car } from '../Cars';
@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Input() carData:Car;
  constructor() { }

  ngOnInit() {
  }

}
