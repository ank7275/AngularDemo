import { Component } from '@angular/core';
import { CARS } from './CarsData';
import { Car } from './Cars';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Component-Interaction';
  cars=CARS;
  car:Car;
  getDetails(car:Car){
    this.car=car;
  }

}
