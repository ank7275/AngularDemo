import { Account } from './account';

export const ACCOUNTS: Account[] = [
  {name: 'Ankit', acc:'23445454554423' },
  {name: 'Ravi', acc:'23445454554423' }

];
