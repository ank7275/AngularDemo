import { Component, OnInit } from '@angular/core';
import { Account } from '../account';
import { ACCOUNTS } from '../account-details';

@Component({
  selector: 'app-heroes',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.css']
})

export class AccountComponent implements OnInit {
  
  Accounts = ACCOUNTS;
  selectedAcc: Account;

  constructor() { }

  ngOnInit() {
  }



  onSelect(account:Account): void {
    this.selectedAcc = account;
  }
}
