export class Account {
  name: string;
  acc: string;
}
